#ifndef LEXER_H
#define LEXER_H
#include <bits/stdc++.h>
#include "Token.h"
#include "Error.h"
using namespace std;
struct Token
{
    TokenType type;
    string s;
    int line;

    Token(TokenType type, string s, int line) : type(type), s(s), line(line)
    {
    }
};
class Lexer
{
public:
    string s;

    vector<Token> tokens;
    vector<Error> errors;

    int index = 0;
    int length;
    int line = 0;

    void getFullWord();
    void getDigit();
    void getSymbol();

    TokenType getIdentType(string word);
    void getString();
    void getChar();
    void skipSpace();

    Lexer(string input);

    void scan();

    void printAns();
};
#endif